<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\RentalAd;
use App\Models\Car;
use App\Models\User;
use App\Services\VehicleFraudDetectionService;
use App\Services\NotificationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Http; // ⬅️ ضروري لعمل طلبات الـ HTTP إلى الـ API الخارجي
use Illuminate\Support\Facades\Log;

class RentalAdController extends Controller
{
    /**
     * عرض جميع إعلانات التأجير مع إمكانية البحث والتصفية الجغرافية.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(Request $request)
    {
        $query = RentalAd::query();

        // تصفية نصية حسب اسم المنطقة
        if ($request->filled('location')) {
            $query->where('location', 'like', '%' . $request->location . '%');
        }

        // تصفية حسب السعر اليومي (min_daily_price, max_daily_price)
        if ($request->filled('min_daily_price')) {
            $query->where('daily_price', '>=', $request->min_daily_price);
        }
        if ($request->filled('max_daily_price')) {
            $query->where('daily_price', '<=', $request->max_daily_price);
        }

        // تصفية حسب السعر الشهري (min_monthly_price, max_monthly_price)
        if ($request->filled('min_monthly_price')) {
            $query->where('monthly_price', '>=', $request->min_monthly_price);
        }
        if ($request->filled('max_monthly_price')) {
            $query->where('monthly_price', '<=', $request->max_monthly_price);
        }

        // تصفية حسب الحالة (status)
        if ($request->has('status') && in_array($request->status, ['pending', 'active', 'rented', 'rejected'])) {
            $query->where('status', $request->status);
        } else {
            // افتراضياً، عرض الإعلانات النشطة فقط
            $query->where('status', 'active');
        }

        $rentalAds = $query->get()->map(function ($ad) {
            return [
                'id' => $ad->id,
                'car_id' => $ad->car_id,
                'user_id' => $ad->user_id,
                'daily_price' => $ad->daily_price,
                'monthly_price' => $ad->monthly_price,
                'rental_conditions' => $ad->rental_conditions,
                'location' => $ad->location,
                'status' => $ad->status,
                'created_at' => $ad->created_at,
                'updated_at' => $ad->updated_at,
            ];
        });

        return response()->json([
            'message' => 'تم جلب إعلانات التأجير بنجاح.',
            'count' => $rentalAds->count(),
            'rental_ads' => $rentalAds,
        ]);
    }

    /**
     * عرض تفاصيل إعلان تأجير محدد.
     *
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show($id)
    {
        $rentalAd = RentalAd::find($id);

        if (!$rentalAd || $rentalAd->status !== 'active') { // عرض الإعلانات النشطة فقط
            return response()->json(['message' => 'إعلان التأجير غير موجود أو غير نشط.'], 404);
        }

        return response()->json([
            'message' => 'تم جلب تفاصيل إعلان التأجير بنجاح.',
            'rental_ad' => [
                'id' => $rentalAd->id,
                'car_id' => $rentalAd->car_id,
                'user_id' => $rentalAd->user_id,
                'daily_price' => $rentalAd->daily_price,
                'monthly_price' => $rentalAd->monthly_price,
                'rental_conditions' => $rentalAd->rental_conditions,
                'location' => $rentalAd->location,
                'status' => $rentalAd->status,
                'created_at' => $rentalAd->created_at,
                'updated_at' => $rentalAd->updated_at,
            ],
        ]);
    }

    /**
     * إضافة إعلان تأجير جديد مع جلب الموقع الجغرافي من LocationIQ يدوياً.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(Request $request)
    {
        $user = $request->user();

        if (!in_array($user->accountType->name, ['individual', 'company'])) {
            return response()->json(['message' => 'ليس لديك الصلاحية لإضافة إعلانات تأجير.'], 403);
        }

        $validator = Validator::make($request->all(), [
            'car_id'            => 'required|exists:cars,id|integer',
            'daily_price'       => 'nullable|numeric|min:0',
            'monthly_price'     => 'nullable|numeric|min:0',
            'rental_conditions' => 'nullable|string',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        if (is_null($request->daily_price) && is_null($request->monthly_price)) {
            return response()->json(['message' => 'يجب تحديد سعر يومي أو شهري على الأقل.'], 422);
        }

        // التحقق من أن السيارة تابعة للمستخدم
        $car = Car::find($request->car_id);
        if (!$car || $car->user_id !== $user->id) {
            return response()->json(['message' => 'هذه السيارة غير موجودة أو لا تنتمي إليك.'], 403);
        }

        // التحقق من أن السيارة معتمدة (approved) من الإدارة قبل السماح بإنشاء إعلان عليها
        if ($car->approval_status !== 'approved') {
            return response()->json([
                'message' => '❌ لا يمكن إنشاء إعلان تأجير لهذه السيارة.',
                'reason' => match ($car->approval_status) {
                    'pending' => 'السيارة بانتظار موافقة الإدارة أولاً.',
                    'rejected' => 'تم رفض هذه السيارة من قبل الإدارة.',
                    default => 'السيارة في حالة غير صحيحة (' . $car->approval_status . ').',
                },
            ], 422);
        }

        // التحقق من عدم وجود إعلان بيع قائم للسيارة
        $existingAd = \App\Models\Ad::where('car_id', $request->car_id)
            ->whereIn('status', ['pending', 'active'])
            ->first();

        if ($existingAd) {
            return response()->json(['message' => '❌ لا يمكن إضافة إعلان تأجير! هذه السيارة معروضة للبيع بالفعل. يجب أن تختار إما البيع أو التأجير فقط.'], 422);
        }

        // التحقق من عدم وجود إعلان تأجير نشط بالفعل
        $existingRentalAd = RentalAd::where('car_id', $request->car_id)
            ->whereIn('status', ['pending', 'active', 'rented'])
            ->first();

        if ($existingRentalAd) {
            return response()->json(['message' => '❌ هذه السيارة لديها إعلان تأجير موجود بالفعل.'], 422);
        }

        // إنشاء إعلان التأجير
        $rentalAd = RentalAd::create([
            'car_id'            => $request->car_id,
            'user_id'           => $user->id,
            'daily_price'       => $request->daily_price,
            'monthly_price'     => $request->monthly_price,
            'rental_conditions' => $request->rental_conditions,
            'location'          => $car->location,
            'status'            => 'pending',
        ]);

        $fraudAnalysis = (new VehicleFraudDetectionService())->analyze($car);

        // إرسال إشعار للأدمن إذا كانت إشارة الاحتيال قوية (لا تُرجع التفاصيل للمستخدم نفسه)
        if ($fraudAnalysis['is_strong_fraud_signal']) {
            $admins = User::where('account_type_id', 3)->get(); // جلب جميع الأدمن
            foreach ($admins as $admin) {
                NotificationService::send(
                    $admin->id,
                    '🚨 تنبيه احتيال محتمل',
                    'إعلان تأجير جديد برقم هيكل ' . $car->vehicle_identifier . ' ظهر ' . $fraudAnalysis['occurrences'] . ' مرات. يرجى مراجعة إعلان التأجير رقم ' . $rentalAd->id . ' قبل الموافقة.',
                    'fraud_alert',
                    [
                        'rental_ad_id' => $rentalAd->id,
                        'car_id'       => $car->id,
                        'occurrences'  => $fraudAnalysis['occurrences'],
                        'price_conflict'       => $fraudAnalysis['price_conflict'],
                        'description_conflict' => $fraudAnalysis['description_conflict'],
                    ]
                );
            }
        }

        return response()->json([
            'message' => '✅ تم إضافة إعلان التأجير بنجاح! ⏳ بانتظار موافقة الإدارة',
            'rental_ad' => [
                'id' => $rentalAd->id,
                'car_id' => $rentalAd->car_id,
                'user_id' => $rentalAd->user_id,
                'daily_price' => $rentalAd->daily_price,
                'monthly_price' => $rentalAd->monthly_price,
                'rental_conditions' => $rentalAd->rental_conditions,
                'location' => $rentalAd->location,
                'status' => $rentalAd->status,
                'created_at' => $rentalAd->created_at,
                'updated_at' => $rentalAd->updated_at,
            ],
        ], 201);
    }
    /**
     * تحديث إعلان تأجير موجود وتعديل الإحداثيات عبر LocationIQ يدوياً عند تغيير الموقع.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     */
   /**
     * تحديث إعلان تأجير موجود وتعديل الموقع عبر الـ Reverse Geocoding عند تغيير الإحداثيات.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     */
  public function update(Request $request, $id)
  {
      $user = $request->user();
      $rentalAd = RentalAd::where('id', $id)->where('user_id', $user->id)->first();

      if (!$rentalAd) {
          return response()->json(['message' => 'إعلان التأجير غير موجود أو ليس لديك صلاحية لتعديله.'], 404);
      }

      $validator = Validator::make($request->all(), [
          'daily_price'       => 'sometimes|numeric|min:0',
          'monthly_price'     => 'sometimes|numeric|min:0',
          'rental_conditions' => 'nullable|string',
      ]);

      if ($validator->fails()) {
          return response()->json($validator->errors(), 422);
      }

      // تحديث حقول rental_ads فقط
      if ($request->has('daily_price')) $rentalAd->daily_price = $request->daily_price;
      if ($request->has('monthly_price')) $rentalAd->monthly_price = $request->monthly_price;
      if ($request->has('rental_conditions')) $rentalAd->rental_conditions = $request->rental_conditions;

      // إعادة الإعلان للمراجعة بعد التعديل
      $rentalAd->status = 'pending';
      $rentalAd->save();

      return response()->json([
          'message' => '✅ تم تحديث الإعلان بنجاح! ⏳ تم إعادته للمراجعة من قبل الإدارة',
          'rental_ad' => [
              'id' => $rentalAd->id,
              'car_id' => $rentalAd->car_id,
              'user_id' => $rentalAd->user_id,
              'daily_price' => $rentalAd->daily_price,
              'monthly_price' => $rentalAd->monthly_price,
              'rental_conditions' => $rentalAd->rental_conditions,
              'location' => $rentalAd->location,
              'status' => $rentalAd->status,
              'created_at' => $rentalAd->created_at,
              'updated_at' => $rentalAd->updated_at,
          ],
      ]);
  }
    /**
     * نشر إعلان تأجير (السماح بنشره عدة مرات)
     * الشروط:
     * 1. حالة الإعلان يجب أن تكون active (موافقة من الأدمن)
     * 2. حالة السيارة يجب أن تكون approved (ليست pending)
     */
    public function publish(Request $request, $id)
    {
        $user = $request->user();
        $rentalAd = RentalAd::where('id', $id)
                           ->where('user_id', $user->id)
                           ->with('car')
                           ->first();

        if (!$rentalAd) {
            return response()->json(['message' => 'إعلان التأجير غير موجود.'], 404);
        }

        // التحقق من أن حالة الإعلان تكون active (موافقة من الأدمن)
        if ($rentalAd->status !== 'active') {
            return response()->json([
                'message' => '❌ لا يمكن نشر هذا الإعلان!',
                'reason' => match($rentalAd->status) {
                    'pending' => 'الإعلان بانتظار موافقة الإدارة',
                    'rejected' => 'الإعلان تم رفضه من قبل الإدارة',
                    'rented' => 'السيارة تم استئجارها بالفعل',
                    default => 'الإعلان في حالة غير صحيحة'
                }
            ], 422);
        }

        // التحقق من أن حالة السيارة تكون approved (ليست pending)
        if ($rentalAd->car->approval_status !== 'approved') {
            return response()->json([
                'message' => '❌ لا يمكن نشر إعلان لسيارة في حالة ' . $rentalAd->car->approval_status,
                'reason' => 'السيارة يجب أن تكون موافق عليها من الإدارة أولاً'
            ], 422);
        }

        // تم نشر الإعلان (يمكن نشره أكثر من مرة)
        // لا نحتاج لتخزين تاريخ النشر في rental_ads حالياً، لكن يمكن إضافته لاحقاً إذا لزم الأمر

        return response()->json([
            'message' => '✅ تم نشر إعلان التأجير بنجاح!',
            'rental_ad' => [
                'id' => $rentalAd->id,
                'car_id' => $rentalAd->car_id,
                'user_id' => $rentalAd->user_id,
                'daily_price' => $rentalAd->daily_price,
                'monthly_price' => $rentalAd->monthly_price,
                'rental_conditions' => $rentalAd->rental_conditions,
                'location' => $rentalAd->location,
                'status' => $rentalAd->status,
                'created_at' => $rentalAd->created_at,
                'updated_at' => $rentalAd->updated_at,
            ],
        ]);
    }

    /**
     * حذف إعلان تأجير وحذف سيارته وصوره بشكل نهائي.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy(Request $request, $id)
    {
        $user = $request->user();
        $rentalAd = RentalAd::where('id', $id)->where('user_id', $user->id)->first();

        if (!$rentalAd) {
            return response()->json(['message' => 'إعلان التأجير غير موجود أو ليس لديك صلاحية لحذفه.'], 404);
        }

        $car = $rentalAd->car;
        if ($car && $car->images) {
            foreach ($car->images as $imagePath) {
                Storage::delete(str_replace('/storage/', 'public/', $imagePath));
            }
        }

        $rentalAd->delete();
        $car->delete(); // حذف السيارة بالتزامن لمنع بقاء بيانات ميتة بقاعدة البيانات

        return response()->json(['message' => 'تم حذف إعلان التأجير بنجاح.'], 200);
    }
}
