<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Auction;
use App\Models\Bid;
use App\Models\Car; // لاستخدام نموذج السيارة
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB; // لاستخدام المعاملات (Transactions)
use Illuminate\Support\Facades\Storage; // لاستخدام تخزين الملفات
use App\Services\NotificationService;
use App\Services\AuctionClosingService;
use App\Services\VehicleFraudDetectionService;

class AuctionController extends Controller

{
    /**
     * عرض جميع المزادات مع إمكانية البحث والتصفية.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\JsonResponse
     */

    public function index(Request $request)
    {
        $query = Auction::with('car.user', 'winner', 'bids'); // تحميل العلاقات الضرورية

        // تصفية حسب حالة المزاد
        if ($request->has('status') && in_array($request->status, ['pending', 'active', 'closed', 'cancelled'])) {
            $query->where('status', $request->status);
        } else {
            // افتراضياً، عرض المزادات النشطة فقط للمستخدمين العاديين
            $query->where('status', 'active');
        }

        // تصفية حسب نوع السيارة (make)
        if ($request->has('make')) {
            $query->whereHas('car', function ($q) use ($request) {
                $q->where('make', 'like', '%' . $request->make . '%');
            });
        }

        // تصفية حسب موديل السيارة (model)
        if ($request->has('model')) {
            $query->whereHas('car', function ($q) use ($request) {
                $q->where('model', 'like', '%' . $request->model . '%');
            });
        }

        // تصفية حسب الموقع (location)
        if ($request->has('location')) {
            $query->whereHas('car', function ($q) use ($request) {
                $q->where('location', 'like', '%' . $request->location . '%');
            });
        }

        // ترتيب حسب وقت الانتهاء (الأقرب أولاً)
        $query->orderBy('end_time', 'asc');

        $auctions = $query->paginate(10);

        return response()->json([
            'message' => 'تم جلب المزادات بنجاح.',
            'auctions' => $auctions,
        ]);
    }


    /**
     * عرض تفاصيل مزاد محدد.
     *
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show($id)
    {
        $auction = Auction::with('car.user', 'winner', 'bids.user')->find($id);

        if (!$auction || $auction->status !== 'active') { // عرض المزادات النشطة فقط
            return response()->json(['message' => 'المزاد غير موجود أو غير نشط.'], 404);
        }

        return response()->json([
            'message' => 'تم جلب تفاصيل المزاد بنجاح.',
            'auction' => $auction,
        ]);
    }

    /**
     * إضافة سيارة للمزاد (إنشاء مزاد جديد).
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(Request $request)
    {
        $user = $request->user();

        // التحقق من أن المستخدم لديه نوع حساب يسمح له بإضافة مزادات (فردي، شركة)
        if (!in_array($user->accountType->name, ['individual', 'company'])) {
            return response()->json(['message' => 'ليس لديك الصلاحية لإضافة مزادات.'], 403);
        }

        // التحقق من وجود اشتراك نشط
        if (!$user->hasActiveSubscription()) {
            return response()->json(['message' => 'يجب أن يكون لديك اشتراك نشط لإضافة مزادات. يرجى الاشتراك أولاً.'], 403);
        }

        $validator = Validator::make($request->all(), [
            'car_id' => 'required|exists:cars,id',
            'starting_price' => 'required|numeric|min:0',
            'duration_hours' => 'required|integer|min:1|max:720',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        DB::beginTransaction();

        try {
            $car = Car::where('id', $request->car_id)
                ->where('user_id', $user->id)
                ->first();

            if (!$car) {
                return response()->json(['message' => 'السيارة غير موجودة أو لا تنتمي لك.'], 404);
            }

            // التحقق من أن السيارة معتمدة (approved) من الإدارة قبل السماح بإضافتها لمزاد
            if ($car->approval_status !== 'approved') {
                DB::rollBack();
                return response()->json([
                    'message' => '❌ لا يمكن إضافة هذه السيارة لمزاد.',
                    'reason' => match ($car->approval_status) {
                        'pending' => 'السيارة بانتظار موافقة الإدارة أولاً.',
                        'rejected' => 'تم رفض هذه السيارة من قبل الإدارة.',
                        default => 'السيارة في حالة غير صحيحة (' . $car->approval_status . ').',
                    },
                ], 422);
            }

            $auction = Auction::create([
                'car_id' => $car->id,
                'user_id' => $user->id,
                'starting_price' => $request->starting_price,
                'current_price' => $request->starting_price,
                'start_time' => now(),
                'end_time' => now()->addHours($request->duration_hours),
                'status' => 'pending',
            ]);

            $fraudAnalysis = (new VehicleFraudDetectionService())->analyze($car);

            // إرسال إشعار لكل الأدمنز إذا كانت إشارة الاحتيال قوية (لا تُرجع التفاصيل للمستخدم نفسه)
            if ($fraudAnalysis['is_strong_fraud_signal']) {
                $admins = User::where('account_type_id', 3)->get(); // جلب جميع الأدمن
                foreach ($admins as $admin) {
                    NotificationService::send(
                        $admin->id,
                        '🚨 تنبيه احتيال في مزاد',
                        'مزاد على سيارة برقم هيكل ' . $car->vehicle_identifier . ' ظهر ' . $fraudAnalysis['occurrences'] . ' مرات. يرجى مراجعة المزاد رقم ' . $auction->id . ' قبل الموافقة.',
                        'fraud_alert',
                        [
                            'car_id'      => $car->id,
                            'auction_id'  => $auction->id,
                            'occurrences' => $fraudAnalysis['occurrences'],
                            'price_conflict'       => $fraudAnalysis['price_conflict'],
                            'description_conflict' => $fraudAnalysis['description_conflict'],
                        ]
                    );
                }
            }

            DB::commit();

            return response()->json([
                'message' => 'تم إضافة المزاد بنجاح. سيتم مراجعة المزاد قبل النشر.',
                'auction' => $auction->load('car'),
            ], 201);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => 'حدث خطأ أثناء إنشاء المزاد.', 'error' => $e->getMessage()], 500);
        }
    }

    /**
     * المزايدة على مزاد.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     */

    public function placeBid(Request $request, $id)
    {
        $user = $request->user();
        $auction = Auction::find($id);

        if (!$auction) {
            return response()->json(['message' => 'المزاد غير موجود.'], 404);
        }

        if ($auction->status !== 'active' || now()->isAfter($auction->end_time)) {
            return response()->json(['message' => 'المزاد غير نشط أو انتهى.'], 400);
        }

        // لا يمكن للبائع المزايدة على مزاده الخاص
        if ($auction->user_id === $user->id) {
            return response()->json(['message' => 'لا يمكنك المزايدة على مزادك الخاص.'], 403);
        }

        $validator = Validator::make($request->all(), [
            'amount' => 'required|numeric|min:' . ($auction->current_price + 1),
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        DB::beginTransaction();

        try {
            // تحديث السعر الحالي للمزاد
            $auction->current_price = $request->amount;
            $auction->save();

            // تسجيل المزايدة
            $bid = Bid::create([
                'auction_id' => $auction->id,
                'user_id' => $user->id,
                'amount' => $request->amount,
            ]);

            // إرسال إشعار لصاحب المزاد بوجود مزايدة جديدة
            if ($auction->user_id !== $user->id) {
                NotificationService::send(
                    $auction->user_id,
                    'مزايدة جديدة على مزادك',
                    'تم تقديم مزايدة جديدة على أحد مزاداتك بقيمة ' . $request->amount . '.',
                    'new_bid',
                    [
                        'auction_id' => $auction->id,
                        'bid_id' => $bid->id,
                        'bidder_id' => $user->id,
                        'amount' => $request->amount,
                    ]
                );
            }

            DB::commit();

            return response()->json([
                'message' => 'تمت المزايدة بنجاح.',
                'bid' => $bid,
                'auction_current_price' => $auction->current_price,
            ]);
        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json([
                'message' => 'حدث خطأ أثناء المزايدة.',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * تحديث مزاد (للمدير أو البائع).
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(Request $request, $id)
    {
        $user = $request->user();
        $auction = Auction::find($id);

        if (!$auction) {
            return response()->json(['message' => 'المزاد غير موجود.'], 404);
        }

        // السماح للمدير أو البائع بتعديل المزاد
        if ($user->accountType->name !== 'admin' && $auction->user_id !== $user->id) {
            return response()->json(['message' => 'ليس لديك صلاحية لتعديل هذا المزاد.'], 403);
        }

        // منع التعديل إذا كان المزاد نشطاً أو مغلقاً (باستثناء المدير لتغيير الحالة)
        if ($auction->status === 'active' || $auction->status === 'closed') {
            if ($user->accountType->name !== 'admin' || !$request->has('status')) {
                return response()->json(['message' => 'لا يمكن تعديل المزاد بعد أن أصبح نشطاً أو مغلقاً.'], 403);
            }
        }

        $validator = Validator::make($request->all(), [
            'make' => 'sometimes|required|string|max:255',
            'model' => 'sometimes|required|string|max:255',
            'year' => 'sometimes|required|integer|min:1900|max:' . (date('Y') + 1),
            'condition' => 'sometimes|required|string|in:new,used',
            'description' => 'nullable|string',
            'location' => 'sometimes|required|string|max:255',
            'images' => 'nullable|array|max:5',
            'images.*' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'starting_price' => 'sometimes|numeric|min:0',
            'duration_hours' => 'sometimes|integer|min:1|max:720',
            'status' => 'sometimes|string|in:pending,active,closed,cancelled', // يمكن للمدير تغيير الحالة
            'winner_id' => 'nullable|exists:users,id', // يمكن للمدير تعيين الفائز يدوياً
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        DB::beginTransaction();

        try {
            // تحديث بيانات السيارة
            $car = $auction->car;
            if ($request->has('make')) $car->make = $request->make;
            if ($request->has('model')) $car->model = $request->model;
            if ($request->has('year')) $car->year = $request->year;
            if ($request->has('condition')) $car->condition = $request->condition;
            if ($request->has('description')) $car->description = $request->description;
            if ($request->has('location')) $car->location = $request->location;

            if ($request->hasFile('images')) {
                foreach ($car->images as $oldImage) {
                    Storage::delete(str_replace('/storage/', 'public/', $oldImage));
                }
                $imagePaths = [];
                foreach ($request->file('images') as $image) {
                    $path = $image->store('public/cars_images');
                    $imagePaths[] = Storage::url($path);
                }
                $car->images = $imagePaths;
            }
            $car->save();

            // تحديث بيانات المزاد
            if ($request->has('starting_price')) $auction->starting_price = $request->starting_price;
            if ($request->has('duration_hours')) {
                $auction->end_time = now()->addHours($request->duration_hours);
            }
            if ($request->has('status')) {
                // منطق خاص لتغيير الحالة (خاصة للمدير)
                if ($request->status === 'active' && $auction->status === 'pending') {
                    $auction->published_at = now(); // إذا تم تفعيل المزاد
                }
                $auction->status = $request->status;
            }
            if ($request->has('winner_id')) $auction->winner_id = $request->winner_id;
            $auction->save();

            DB::commit();

            return response()->json([
                'message' => 'تم تحديث المزاد بنجاح.',
                'auction' => $auction->load('car'),
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => 'حدث خطأ أثناء تحديث المزاد.', 'error' => $e->getMessage()], 500);
        }
    }

    //
    public function closeExpiredAuctions()
    {
        $expiredAuctions = Auction::where('status', 'active')
            ->where('end_time', '<=', now())
            ->get();

        $results = [];

        foreach ($expiredAuctions as $auction) {
            try {
                $closedAuction = AuctionClosingService::closeExpiredAuction($auction);

                $results[] = [
                    'auction_id' => $closedAuction->id,
                    'status' => $closedAuction->status,
                    'winner_id' => $closedAuction->winner_id,
                    'current_price' => $closedAuction->current_price,
                    'final_price_status' => $closedAuction->final_price_status,
                    'closed_reason' => $closedAuction->closed_reason,
                ];
            } catch (\Exception $e) {
                $results[] = [
                    'auction_id' => $auction->id,
                    'error' => $e->getMessage(),
                ];
            }
        }

        return response()->json([
            'message' => 'تم فحص وإغلاق المزادات المنتهية.',
            'results' => $results,
        ]);
    }

    public function acceptFinalPrice(Request $request, $id)
    {
        $user = $request->user();
        $auction = Auction::find($id);

        if (!$auction) {
            return response()->json(['message' => 'المزاد غير موجود.'], 404);
        }

        if ($auction->user_id !== $user->id) {
            return response()->json(['message' => 'ليس لديك صلاحية لقبول السعر النهائي لهذا المزاد.'], 403);
        }

        if ($auction->status !== 'closed') {
            return response()->json(['message' => 'لا يمكن قبول السعر النهائي إلا بعد إغلاق المزاد.'], 400);
        }

        if (!$auction->winner_id) {
            return response()->json(['message' => 'لا يوجد فائز محدد لهذا المزاد.'], 400);
        }

        if ($auction->final_price_status === 'accepted') {
            return response()->json(['message' => 'تم قبول السعر النهائي مسبقًا.'], 400);
        }

        if ($auction->final_price_status === 'rejected') {
            return response()->json(['message' => 'لا يمكن قبول السعر النهائي بعد رفضه.'], 400);
        }

        $auction->final_price_status = 'accepted';
        $auction->final_price_decided_at = now();
        $auction->save();

        NotificationService::send(
            $auction->winner_id,
            'تم قبول السعر النهائي للمزاد',
            'وافق صاحب المزاد على السعر النهائي. يمكنك متابعة عملية إتمام البيع.',
            'auction_final_price_accepted',
            [
                'auction_id' => $auction->id,
                'current_price' => $auction->current_price,
            ]
        );

        return response()->json([
            'message' => 'تم قبول السعر النهائي بنجاح.',
            'auction' => $auction->fresh(['car', 'user', 'winner']),
        ]);
    }

    public function rejectFinalPrice(Request $request, $id)
    {
        $user = $request->user();
        $auction = Auction::find($id);

        if (!$auction) {
            return response()->json(['message' => 'المزاد غير موجود.'], 404);
        }

        if ($auction->user_id !== $user->id) {
            return response()->json(['message' => 'ليس لديك صلاحية لرفض السعر النهائي لهذا المزاد.'], 403);
        }

        if ($auction->status !== 'closed') {
            return response()->json(['message' => 'لا يمكن رفض السعر النهائي إلا بعد إغلاق المزاد.'], 400);
        }

        if (!$auction->winner_id) {
            return response()->json(['message' => 'لا يوجد فائز محدد لهذا المزاد.'], 400);
        }

        if ($auction->final_price_status === 'accepted') {
            return response()->json(['message' => 'لا يمكن رفض السعر النهائي بعد قبوله.'], 400);
        }

        if ($auction->final_price_status === 'rejected') {
            return response()->json(['message' => 'تم رفض السعر النهائي مسبقًا.'], 400);
        }

        $auction->final_price_status = 'rejected';
        $auction->final_price_decided_at = now();
        $auction->save();

        NotificationService::send(
            $auction->winner_id,
            'تم رفض السعر النهائي للمزاد',
            'رفض صاحب المزاد السعر النهائي، ولن يتم إتمام البيع لهذا المزاد.',
            'auction_final_price_rejected',
            [
                'auction_id' => $auction->id,
                'current_price' => $auction->current_price,
            ]
        );

        return response()->json([
            'message' => 'تم رفض السعر النهائي بنجاح.',
            'auction' => $auction->fresh(['car', 'user', 'winner']),
        ]);
    }
    //
    /**
     * حذف مزاد.
     *
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy(Request $request, $id)
    {
        $user = $request->user();
        $auction = Auction::find($id);

        if (!$auction) {
            return response()->json(['message' => 'المزاد غير موجود.'], 404);
        }

        // السماح للمدير أو البائع بحذف المزاد إذا لم يكن نشطاً
        if ($user->accountType->name !== 'admin' && $auction->user_id !== $user->id) {
            return response()->json(['message' => 'ليس لديك صلاحية لحذف هذا المزاد.'], 403);
        }

        if ($auction->status === 'active') {
            return response()->json(['message' => 'لا يمكن حذف مزاد نشط. يرجى إلغاؤه أولاً.'], 400);
        }

        DB::beginTransaction();

        try {
            // حذف الصور المرتبطة بالسيارة قبل حذف السيارة والمزاد
            $car = $auction->car;
            if ($car && $car->images) {
                foreach ($car->images as $imagePath) {
                    Storage::delete(str_replace('/storage/', 'public/', $imagePath));
                }
            }

            $auction->delete();
            $car->delete(); // سيتم حذف السيارة أيضاً بسبب علاقة cascade في الهجرة

            DB::commit();

            return response()->json(['message' => 'تم حذف المزاد بنجاح.'], 200);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['message' => 'حدث خطأ أثناء حذف المزاد.', 'error' => $e->getMessage()], 500);
        }
    }

    /**
     * وظيفة مساعدة لإنهاء المزادات المنتهية وتحديد الفائز.
     * يمكن استدعاؤها عبر Cron Job أو Event Listener.
     *
     * @return void
     */


}
