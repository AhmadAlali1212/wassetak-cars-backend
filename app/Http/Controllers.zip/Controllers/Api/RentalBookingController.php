<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\RentalAd;
use App\Models\RentalBooking;
use App\Models\User;
use App\Services\VehicleFraudDetectionService;
use App\Services\NotificationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class RentalBookingController extends Controller
{
    /**
     * إنشاء حجز جديد لإعلان تأجير قائم.
     *
     * الفحص الأهم هنا: قبل تأكيد الحجز، نتحقق هل فترة الحجز
     * المطلوبة تتقاطع زمنياً مع حجز فعّال آخر موجود على نفس السيارة
     * الفعلية (نفس vehicle_identifier)، حتى لو كان على إعلان مختلف.
     *
     * بخلاف "كشف الاحتيال" في إعلانات البيع (الذي يبقى مؤشراً
     * احتمالياً يحتاج تقدير الأدمن)، تقاطع فترتي تأجير على سيارة
     * واحدة هو تعارض حسابي صارم لا يقبل إلا تفسيراً واحداً: إما
     * خطأ بيانات أو احتيال فعلي. لذلك يُرفض الحجز فوراً (422) ولا
     * يُترك القرار للأدمن - لا يوجد "احتمال" هنا، فقط تأكيد رياضي.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'rental_ad_id' => 'required|exists:rental_ads,id',
            'start_date'   => 'required|date|after_or_equal:today',
            'end_date'     => 'required|date|after:start_date',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        $user = $request->user();

        $rentalAd = RentalAd::with('car')->find($request->rental_ad_id);

        if (!$rentalAd) {
            return response()->json(['message' => 'إعلان التأجير غير موجود.'], 404);
        }

        // لا يجوز الحجز إلا على إعلان معتمد ومتاح فعلياً
        if (!in_array($rentalAd->status, ['active', 'rented'])) {
            return response()->json(['message' => '❌ لا يمكن الحجز على هذا الإعلان حالياً.'], 422);
        }

        if (!$rentalAd->car) {
            return response()->json(['message' => 'تعذر العثور على السيارة المرتبطة بهذا الإعلان.'], 422);
        }

        // الفحص الحاسم: هل تتقاطع الفترة المطلوبة مع حجز فعّال آخر
        // على نفس السيارة الفعلية (نفس رقم الهيكل)؟
        $overlapReport = (new VehicleFraudDetectionService())->analyzeRentalOverlap(
            $rentalAd->car,
            $request->start_date,
            $request->end_date
        );

        if ($overlapReport['has_double_rental_conflict']) {
            // توثيق الحالة للأدمن دون انتظار قراره - الرفض فوري وحاسم
            $admins = User::whereHas('accountType', fn ($q) => $q->where('name', 'admin'))->get();
            foreach ($admins as $admin) {
                NotificationService::send(
                    $admin->id,
                    '🚨 محاولة تأجير مزدوج مرفوضة',
                    'تم رفض حجز جديد على سيارة برقم هيكل ' . $rentalAd->car->vehicle_identifier
                        . ' تلقائياً لتقاطعه زمنياً مع ' . $overlapReport['overlapping_count'] . ' حجز/حجوزات قائمة.',
                    'fraud_alert',
                    [
                        'rental_ad_id' => $rentalAd->id,
                        'attempted_by' => $user->id,
                        'start_date'   => $request->start_date,
                        'end_date'     => $request->end_date,
                    ]
                );
            }

            return response()->json([
                'message' => '❌ لا يمكن إتمام هذا الحجز. السيارة محجوزة فعلاً في فترة متقاطعة مع الفترة المطلوبة.',
                'reason'  => 'rental_overlap_conflict',
            ], 422);
        }

        $booking = RentalBooking::create([
            'rental_ad_id' => $rentalAd->id,
            'user_id'      => $user->id,
            'start_date'   => $request->start_date,
            'end_date'     => $request->end_date,
            'status'       => 'confirmed',
        ]);

        return response()->json([
            'message' => '✅ تم تأكيد الحجز بنجاح.',
            'booking' => $booking,
        ], 201);
    }

    /**
     * عرض كل حجوزات المستخدم الحالي.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function myBookings(Request $request)
    {
        $bookings = RentalBooking::with('rentalAd.car')
            ->where('user_id', $request->user()->id)
            ->latest()
            ->get();

        return response()->json(['bookings' => $bookings]);
    }

    /**
     * إلغاء حجز قائم (من قبل صاحب الحجز نفسه فقط).
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function cancel(Request $request, $id)
    {
        $booking = RentalBooking::find($id);

        if (!$booking || $booking->user_id !== $request->user()->id) {
            return response()->json(['message' => 'الحجز غير موجود أو لا يخصك.'], 404);
        }

        $booking->status = 'cancelled';
        $booking->save();

        return response()->json(['message' => '✅ تم إلغاء الحجز بنجاح.']);
    }
}
