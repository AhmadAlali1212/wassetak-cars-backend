<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Car;
use App\Models\Ad;


use App\Services\NotificationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Http; // لإرسال طلبات الـ API للخرائط
use App\Models\User;

class CarController extends Controller
{
    /**
     * عرض جميع إعلانات البيع مع إمكانية البحث والتصفية العادية والجغرافية.
     */
public function index(Request $request)
{
    $query = Ad::with('car.user');

    // التحقق من أن الإعلان والسيارة موافق عليهما
    $query->where('approval_status', 'approved')
          ->whereHas('car', function ($q) {
              $q->where('approval_status', 'approved');
          });

    // 1. الفلترة حسب حالة الإعلان
    if ($request->has('status') && in_array($request->status, ['pending', 'active', 'sold', 'rejected'])) {
        $query->where('status', $request->status);
    } else {
        $query->where('status', 'active');
    }

    // 2. الفلترة حسب السعر
    if ($request->has('min_price')) {
        $query->where('price', '>=', $request->min_price);
    }
    if ($request->has('max_price')) {
        $query->where('price', '<=', $request->max_price);
    }

    // 3. الفلترة حسب المستخدم
    if ($request->has('user_id')) {
        $query->where('user_id', $request->user_id);
    }

    // 4. فلاتر جدول السيارات (Car) مجمعة داخل غلاف واحد لضمان دمج الشروط (AND)
    $query->whereHas('car', function ($q) use ($request) {

        if ($request->has('make')) {
            $q->where('make', 'like', '%' . $request->make . '%');
        }

        if ($request->has('model')) {
            $q->where('model', 'like', '%' . $request->model . '%');
        }

        if ($request->has('condition')) {
            $q->where('condition', $request->condition);
        }

        if ($request->has('location')) {
            $q->where('location', 'like', '%' . $request->location . '%');
        }

        // 🔥 الشرط الجغرافي الصارم والمحمي من قيم NULL
        if ($request->has(['user_lat', 'user_lng', 'radius'])) {
            $userLat = $request->user_lat;
            $userLng = $request->user_lng;
            $radius  = $request->radius;

            // استبعاد أي سيارة إحداثياتها فارغة في قاعدة البيانات فوراً
            $q->whereNotNull('latitude')
              ->whereNotNull('longitude')
              ->whereRaw("(6371 * acos(cos(radians(?)) * cos(radians(latitude)) * cos(radians(longitude) - radians(?)) + sin(radians(?)) * sin(radians(latitude)))) <= ?",
              [$userLat, $userLng, $userLat, $radius]);
        }
    });

    $ads = $query->paginate(10);

    // تحسين البيانات المرجعة - إخفاء vehicle_identifier من الآخرين
    $ads->getCollection()->transform(function ($ad) {
        return [
            'id' => $ad->id,
            'car_id' => $ad->car_id,
            'user_id' => $ad->user_id,
            'price' => $ad->price,
            'status' => $ad->status,
            'approval_status' => $ad->approval_status,
            'published_at' => $ad->published_at,
            'expires_at' => $ad->expires_at,
            'car' => [
                'id' => $ad->car->id,
                'make' => $ad->car->make,
                'model' => $ad->car->model,
                'year' => $ad->car->year,
                'condition' => $ad->car->condition,
                'location' => $ad->car->location,
                'latitude' => $ad->car->latitude,
                'longitude' => $ad->car->longitude,
                'images' => $ad->car->images,
            ],
            'seller' => [
                'id' => $ad->user->id,
                'name' => $ad->user->name,
                'phone' => $ad->user->phone,
            ],
        ];
    });

    return response()->json([
        'message' => '✅ تم جلب إعلانات البيع بنجاح وفقاً لمحددات البحث الحالية.',
        'total_count' => $ads->total(),
        'ads' => $ads,
    ]);
}
    /**
     * عرض تفاصيل إعلان بيع محدد
     */
    public function show($id)
    {
        $ad = Ad::with('car.user')->find($id);

        if (!$ad) {
            return response()->json(['message' => 'الإعلان غير موجود.'], 404);
        }

        if ($ad->approval_status !== 'approved' || $ad->status !== 'active') {
            return response()->json([
                'message' => 'الإعلان غير متاح حالياً.',
                'reason' => $ad->approval_status !== 'approved'
                    ? 'الإعلان بانتظار موافقة الإدارة'
                    : 'الإعلان غير نشط',
            ], 404);
        }

        // إخفاء vehicle_identifier من الآخرين - إظهاره فقط للمالك
        $carData = $ad->car->toArray();
        unset($carData['vehicle_identifier']);

        return response()->json([
            'message' => 'تم جلب تفاصيل الإعلان بنجاح.',
            'ad' => [
                'id' => $ad->id,
                'car_id' => $ad->car_id,
                'user_id' => $ad->user_id,
                'price' => $ad->price,
                'status' => $ad->status,
                'approval_status' => $ad->approval_status,
                'published_at' => $ad->published_at,
                'expires_at' => $ad->expires_at,
                'created_at' => $ad->created_at,
                'car' => $carData,
                'seller' => [
                    'id' => $ad->user->id,
                    'name' => $ad->user->name,
                    'email' => $ad->user->email,
                    'phone' => $ad->user->phone,
                ],
            ],
        ]);
    }

    /**
     * إضافة إعلان بيع جديد مع تحديد الموقع تلقائياً عبر الإحداثيات الجغرافية
     */
    public function store(Request $request)
    {
        $user = $request->user();

        if (!in_array($user->accountType->name, ['individual', 'company'])) {
            return response()->json(['message' => 'ليس لديك الصلاحية لإضافة إعلانات بيع.'], 403);
        }

        $validator = Validator::make($request->all(), [
            'make' => 'required|string|max:255',
            'model' => 'required|string|max:255',
            'year' => 'required|integer|min:1900|max:' . (date('Y') + 1),
            'condition' => 'required|string|in:new,used',
            'description' => 'nullable|string',
    'vehicle_identifier' => 'required|string|max:255',
            'latitude' => 'required|numeric|between:-90,90',
            'longitude' => 'required|numeric|between:-180,180',
            'images' => 'nullable|array|max:5',
            'images.*' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        // 🗺️ تحويل الإحداثيات تلقائياً إلى نص باستخدام LocationIQ المستقر
        $detectedLocation = 'موقع غير معروف';
        try {
            // ⚠️ ضع مفتاح الـ Token الخاص بك المجلوب من موقع LocationIQ هنا بدلاً من النص أدناه
            $apiKey = 'pk.2ebc5f372c19bce2742a82d76c2c8fc7';

            $response = Http::get("https://us1.locationiq.com/v1/reverse", [
                'key'             => $apiKey,
                'lat'             => $request->latitude,
                'lon'             => $request->longitude,
                'format'          => 'json',
                'accept-language' => 'ar' // النتيجة باللغة العربية
            ]);

            if ($response->successful()) {
                $address = $response->json()['address'] ?? [];
                // استخلاص اسم المدينة أو المحافظة والدولة
                $city = $address['city'] ?? $address['town'] ?? $address['village'] ?? $address['state'] ?? '';
                $country = $address['country'] ?? '';

                if (!empty($city) && !empty($country)) {
                    $detectedLocation = $city . '، ' . $country;
                } else {
                    $detectedLocation = $response->json()['display_name'] ?? 'موقع غير معروف';
                }
            }
        } catch (\Exception $e) {
            $detectedLocation = 'موقع غير معروف';
        }

        // حفظ السيارة مع الموقع المكتشف تلقائياً
        $car = Car::create([
            'user_id' => $user->id,
            'make' => $request->make,
            'model' => $request->model,
            'year' => $request->year,
            'condition' => $request->condition,
            'description' => $request->description,
            'vehicle_identifier' => $request->vehicle_identifier,
            'location' => $detectedLocation,
            'latitude' => $request->latitude,
            'longitude' => $request->longitude,
        ]);

        // معالجة تحميل الصور
        $imagePaths = [];
        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $image) {
                $path = $image->store('public/cars_images');
                $imagePaths[] = Storage::url($path);
            }
        }
        $car->images = $imagePaths;
        $car->save();

        return response()->json([
            'message' => 'تم إضافة السيارة بنجاح! ⏳ السيارة بانتظار موافقة الإدارة. استخدم car_id لإنشاء إعلان جديد.',
            'status' => 'pending_approval',
            'approval_info' => [
                'approval_status' => $car->approval_status,
                'message' => 'ستتم مراجعة السيارة من قبل الإدارة',
            ],
            'car' => [
                'id' => $car->id,
                'user_id' => $car->user_id,
                'make' => $car->make,
                'model' => $car->model,
                'year' => $car->year,
                'condition' => $car->condition,
                'description' => $car->description,
                'location' => $car->location,
                'latitude' => $car->latitude,
                'longitude' => $car->longitude,
                'images' => $car->images,
                'approval_status' => $car->approval_status,
                'approval_reason' => $car->approval_reason,
                'approved_at' => $car->approved_at,
                'created_at' => $car->created_at,
                'updated_at' => $car->updated_at,
            ],
        ], 201);
    }

    /**
     * تحديث بيانات السيارة وموقعها الجغرافي تلقائياً عند تغيير الإحداثيات
     */
    public function update(Request $request, $id)
    {
        $user = $request->user();
        $car = Car::where('id', $id)->where('user_id', $user->id)->first();

        if (!$car) {
            return response()->json(['message' => 'السيارة غير موجودة أو ليس لديك صلاحية لتعديلها.'], 404);
        }

        $validator = Validator::make($request->all(), [
            'make' => 'sometimes|required|string|max:255',
            'model' => 'sometimes|required|string|max:255',
            'year' => 'sometimes|required|integer|min:1900|max:' . (date('Y') + 1),
            'condition' => 'sometimes|required|string|in:new,used',
            'description' => 'nullable|string',
           'vehicle_identifier' => 'sometimes|required|string|max:255',
            'latitude' => 'sometimes|required|numeric|between:-90,90',
            'longitude' => 'sometimes|required|numeric|between:-180,180',
            'images' => 'nullable|array|max:5',
            'images.*' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        if ($request->has('make')) $car->make = $request->make;
        if ($request->has('model')) $car->model = $request->model;
        if ($request->has('year')) $car->year = $request->year;
        if ($request->has('condition')) $car->condition = $request->condition;
        if ($request->has('description')) $car->description = $request->description;
        if ($request->has('vehicle_identifier')) $car->vehicle_identifier = $request->vehicle_identifier;

        // تحديث الاسم النصي للموقع تلقائياً عند تعديل الإحداثيات الجغرافية
        if ($request->has(['latitude', 'longitude'])) {
            $car->latitude = $request->latitude;
            $car->longitude = $request->longitude;

            try {
                $apiKey = 'pk.2ebc5f372c19bce2742a82d76c2c8fc7'; // ⚠️ ضع الـ Token الخاص بك هنا أيضاً

                $response = Http::get("https://us1.locationiq.com/v1/reverse", [
                    'key'             => $apiKey,
                    'lat'             => $request->latitude,
                    'lon'             => $request->longitude,
                    'format'          => 'json',
                    'accept-language' => 'ar'
                ]);

                if ($response->successful()) {
                    $address = $response->json()['address'] ?? [];
                    $city = $address['city'] ?? $address['town'] ?? $address['village'] ?? $address['state'] ?? '';
                    $country = $address['country'] ?? '';
                    if (!empty($city) && !empty($country)) {
                        $car->location = $city . '، ' . $country;
                    }
                }
            } catch (\Exception $e) {
                // تجاوز الخطأ في حال تعطل الشبكة والاحتفاظ بالبيانات السابقة
            }
        }

        // معالجة الصور
        if ($request->hasFile('images')) {
            foreach ($car->images as $oldImage) {
                Storage::delete(str_replace('/storage/', 'public/', $oldImage));
            }
            $imagePaths = [];
            foreach ($request->file('images') as $image) {
                $path = $image->store('public/cars_images');
                $imagePaths[] = Storage::url($path);
            }
            $car->images = $imagePaths;
        }
        $car->save();

        return response()->json([
            'message' => 'تم تحديث بيانات السيارة والموقع تلقائياً بنجاح. ⏳ في انتظار إعادة مراجعة الإدارة.',
            'approval_info' => [
                'approval_status' => $car->approval_status,
                'previous_approval' => $car->wasChanged('approval_status') ? 'تم إعادة تعيين الحالة إلى pending' : 'بدون تغيير',
            ],
            'car' => [
                'id' => $car->id,
                'user_id' => $car->user_id,
                'make' => $car->make,
                'model' => $car->model,
                'year' => $car->year,
                'condition' => $car->condition,
                'description' => $car->description,
                'location' => $car->location,
                'latitude' => $car->latitude,
                'longitude' => $car->longitude,
                'images' => $car->images,
                'approval_status' => $car->approval_status,
                'approval_reason' => $car->approval_reason,
                'approved_at' => $car->approved_at,
                'updated_at' => $car->updated_at,
            ],
        ]);
    }

    /**
     * حذف السيارة والإعلانات المرتبطة بها
     */
    public function destroy(Request $request, $id)
    {
        $user = $request->user();

        $car = Car::where('id', $id)
                  ->where('user_id', $user->id)
                  ->first();

        if (!$car) {
            return response()->json(['message' => 'السيارة غير موجودة أو ليس لديك صلاحية لحذفها.'], 404);
        }

        // حذف الصور المرتبطة بالسيارة
        if ($car->images) {
            foreach ($car->images as $imagePath) {
                Storage::delete(str_replace('/storage/', 'public/', $imagePath));
            }
        }

        // حذف جميع الإعلانات المرتبطة بهذه السيارة
        Ad::where('car_id', $car->id)->delete();

        // حذف السيارة
        $car->delete();

        return response()->json(['message' => 'تم حذف السيارة والإعلانات المرتبطة بها بنجاح.'], 200);
    }






public function requestInspection($id)
{
    // التأكد أن السيارة تابعة للمستخدم الحالي
    $car = Car::where('user_id', auth()->id())->findOrFail($id);

    // إرسال إشعار للأدمن (مثلاً الأدمن يحمل المعرف رقم 1)
    $adminId = 1;
    NotificationService::send(
        $adminId,
        'طلب فحص فني جديد 🚗',
        "طلب المستخدم فحصاً فنياً لسيارته المرفوعة بمعرف: {$car->vehicle_identifier}",
        'inspection_request',
        [
            'car_id' => $car->id,
            'user_id' => $car->user_id,
            'location' => $car->location
        ]
    );

    return response()->json([
        'success' => true,
        'message' => 'تم إرسال طلب الفحص بنجاح، سيتواصل معكم الفاحص المعتمد قريباً إن شاء الله.'
    ]);
}
}
