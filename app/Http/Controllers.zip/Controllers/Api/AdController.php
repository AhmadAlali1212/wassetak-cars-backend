<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Ad;
use App\Models\Car;
use App\Services\VehicleFraudDetectionService;
use App\Services\NotificationService;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class AdController extends Controller
{
    /**
     * إنشاء إعلان بيع جديد لسيارة موجودة
     */
    public function store(Request $request)
    {
        $user = $request->user();

        if (!in_array($user->accountType->name, ['individual', 'company'])) {
            return response()->json(['message' => 'ليس لديك الصلاحية لإضافة إعلانات بيع.'], 403);
        }

        $validator = Validator::make($request->all(), [
            'car_id' => 'required|exists:cars,id',
            'price' => 'required|numeric|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        // التحقق من أن السيارة تابعة للمستخدم الحالي
        $car = Car::where('id', $request->car_id)
                  ->where('user_id', $user->id)
                  ->first();

        if (!$car) {
            return response()->json(['message' => 'السيارة غير موجودة أو لا تابعة لك.'], 404);
        }



        // التحقق من عدم وجود إعلان تأجير قائم للسيارة
        $existingRentalAd = \App\Models\RentalAd::where('car_id', $request->car_id)
            ->whereIn('status', ['pending', 'active', 'rented'])
            ->first();

        if ($existingRentalAd) {
            return response()->json(['message' => '❌ لا يمكن إضافة إعلان بيع! هذه السيارة معروضة للتأجير بالفعل. يجب أن تختار إما البيع أو التأجير فقط.'], 422);
        }

      // منع إنشاء إعلان جديد فقط إذا كان هناك إعلان معلّق بانتظار مراجعة الإدارة
$pendingAd = Ad::where('car_id', $request->car_id)
    ->where('status', 'pending')
    ->first();

if ($pendingAd) {
    return response()->json([
        'message' => '❌ لا يمكن إنشاء إعلان جديد لهذه السيارة.',
        'reason'  => 'يوجد إعلان بانتظار مراجعة الإدارة، انتظر حتى تتم المراجعة أولاً.',
    ], 422);
}

        // إنشاء الإعلان
        $ad = Ad::create([
            'car_id' => $car->id,
            'user_id' => $user->id,
            'price' => $request->price,
            'status' => 'pending',
            'published_at' => null,
            'expires_at' => null,
        ]);

        $fraudAnalysis = (new VehicleFraudDetectionService())->analyze($car);

        // إرسال إشعار للأدمن إذا كانت إشارة الاحتيال قوية
        if ($fraudAnalysis['is_strong_fraud_signal']) {
            $admins = User::where('account_type_id', 3)->get(); // جلب جميع الأدمن
            foreach ($admins as $admin) {
                NotificationService::send(
                    $admin->id,
                    '🚨 تنبيه احتيال محتمل',
                    'إعلان جديد برقم هيكل ' . $car->vehicle_identifier . ' ظهر ' . $fraudAnalysis['occurrences'] . ' مرات. يرجى مراجعة الإعلان رقم ' . $ad->id . ' قبل الموافقة.',
                    'fraud_alert',
                    [
                        'ad_id'       => $ad->id,
                        'car_id'      => $car->id,
                        'occurrences' => $fraudAnalysis['occurrences'],
                        'price_conflict'       => $fraudAnalysis['price_conflict'],
                        'description_conflict' => $fraudAnalysis['description_conflict'],
                    ]
                );
            }
        }

        return response()->json([
            'message' => '✅ تم إنشاء الإعلان بنجاح! ⏳ الإعلان بانتظار موافقة الإدارة.',
            'status' => 'pending',
            'ad' => [
                'id'           => $ad->id,
                'car_id'       => $ad->car_id,
                'user_id'      => $ad->user_id,
                'price'        => $ad->price,
                'status'       => $ad->status,
                'published_at' => $ad->published_at,
                'expires_at'   => $ad->expires_at,
                'created_at'   => $ad->created_at,
            ],
        ], 201);
    }

    /**
     * عرض إعلانات المستخدمين الآخرين (النشطة) مع إمكانية البحث والفلترة
     */
    public function otherUsersAds(Request $request)
    {
        $user = $request->user();
        $query = Ad::where('user_id', '!=',$user->id)
                   ->where('status', 'active')
                   ->with('car.user')
                   ->whereHas('car', function ($q) {
                       $q->where('approval_status', 'approved'); // التحقق من موافقة السيارة
                   });

        // الفلترة حسب السعر
        if ($request->has('min_price')) {
            $query->where('price', '>=', $request->min_price);
        }
        if ($request->has('max_price')) {
            $query->where('price', '<=', $request->max_price);
        }

        // فلاتر بيانات السيارة مع whereHas
        $query->whereHas('car', function ($q) use ($request) {
            if ($request->has('make')) {
                $q->where('make', 'like', '%' . $request->make . '%');
            }
            if ($request->has('model')) {
                $q->where('model', 'like', '%' . $request->model . '%');
            }
            if ($request->has('condition')) {
                $q->where('condition', $request->condition);
            }
            if ($request->has('location')) {
                $q->where('location', 'like', '%' . $request->location . '%');
            }

            // البحث الجغرافي
            if ($request->has(['user_lat', 'user_lng', 'radius'])) {
                $userLat = $request->user_lat;
                $userLng = $request->user_lng;
                $radius = $request->radius;

                $q->whereNotNull('latitude')
                  ->whereNotNull('longitude')
                  ->whereRaw("(6371 * acos(cos(radians(?)) * cos(radians(latitude)) * cos(radians(longitude) - radians(?)) + sin(radians(?)) * sin(radians(latitude)))) <= ?",
                  [$userLat, $userLng, $userLat, $radius]);
            }
        });

        $ads = $query->get();

        // تحويل البيانات
        $formattedAds = $ads->map(function ($ad) {
            return [
                'id' => $ad->id,
                'car_id' => $ad->car_id,
                'user_id' => $ad->user_id,
                'price' => $ad->price,
                'status' => $ad->status,
                'published_at' => $ad->published_at,
                'expires_at' => $ad->expires_at,
                'created_at' => $ad->created_at,
                'car' => [
                    'id' => $ad->car->id,
                    'make' => $ad->car->make,
                    'model' => $ad->car->model,
                    'year' => $ad->car->year,
                    'condition' => $ad->car->condition,
                    'location' => $ad->car->location,
                    'latitude' => $ad->car->latitude,
                    'longitude' => $ad->car->longitude,
                    'images' => $ad->car->images,
                ],
                'seller' => [
                    'id' => $ad->user->id,
                    'name' => $ad->user->name,
                    'phone' => $ad->user->phone,
                ],
            ];
        });

        return response()->json([
            'message' => '✅ تم جلب إعلانات المستخدمين الآخرين بنجاح.',
            'count' => $formattedAds->count(),
            'ads' => $formattedAds,
        ]);
    }

    /**
     * عرض إعلانات المستخدم الحالي
     */
    public function myAds(Request $request)
    {
        $user = $request->user();

        $query = Ad::where('user_id', $user->id)->with('car');

        // الفلترة حسب الحالة إذا طُلب
        if ($request->has('status') && in_array($request->status, ['pending', 'active', 'sold', 'rejected'])) {
            $query->where('status', $request->status);
        }

        // الفلترة حسب حالة الموافقة
        if ($request->has('status') && in_array($request->status, ['pending', 'active', 'rejected', 'sold'])) {
            $query->where('status', $request->status);
        }

        $ads = $query->get();

        // تحويل البيانات
        $formattedAds = $ads->map(function ($ad) {
            return [
                'id' => $ad->id,
                'car_id' => $ad->car_id,
                'price' => $ad->price,
                'status' => $ad->status,
                'published_at' => $ad->published_at,
                'expires_at' => $ad->expires_at,
                'created_at' => $ad->created_at,
                'car' => [
                    'id' => $ad->car->id,
                    'make' => $ad->car->make,
                    'model' => $ad->car->model,
                    'year' => $ad->car->year,
                    'condition' => $ad->car->condition,
                ],
            ];
        });

        return response()->json([
            'message' => 'تم جلب إعلاناتك بنجاح.',
            'count' => $formattedAds->count(),
            'ads' => $formattedAds,
        ]);
    }

    /**
     * عرض إعلان محدد للمستخدم الحالي
     */
    public function show(Request $request, $id)
    {
        $user = $request->user();
        $ad = Ad::where('id', $id)
                ->where('user_id', $user->id)
                ->with('car')
                ->first();

        if (!$ad) {
            return response()->json(['message' => 'الإعلان غير موجود.'], 404);
        }

        return response()->json([
            'message' => 'تم جلب تفاصيل الإعلان بنجاح.',
            'ad' => [
                'id' => $ad->id,
                'car_id' => $ad->car_id,
                'user_id' => $ad->user_id,
                'price' => $ad->price,
                'status' => $ad->status,
                'published_at' => $ad->published_at,
                'expires_at' => $ad->expires_at,
                'created_at' => $ad->created_at,
                'car' => [
                    'id' => $ad->car->id,
                    'make' => $ad->car->make,
                    'model' => $ad->car->model,
                    'year' => $ad->car->year,
                    'condition' => $ad->car->condition,
                    'description' => $ad->car->description,
                    'location' => $ad->car->location,
                    'latitude' => $ad->car->latitude,
                    'longitude' => $ad->car->longitude,
                    'images' => $ad->car->images,
                ],
            ],
        ]);
    }

    /**
     * تحديث إعلان
     */
    public function update(Request $request, $id)
    {
        $user = $request->user();
        $ad = Ad::where('id', $id)
                ->where('user_id', $user->id)
                ->first();

        if (!$ad) {
            return response()->json(['message' => 'الإعلان غير موجود.'], 404);
        }

        $validator = Validator::make($request->all(), [
            'price' => 'sometimes|required|numeric|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json($validator->errors(), 422);
        }

        if ($request->has('price')) {
            $ad->price = $request->price;
        }

        $ad->save();

        return response()->json([
            'message' => '✅ تم تحديث الإعلان بنجاح. ⏳ في انتظار إعادة مراجعة الإدارة.',
            'ad' => [
                'id' => $ad->id,
                'car_id' => $ad->car_id,
                'user_id' => $ad->user_id,
                'price' => $ad->price,
                'status' => $ad->status,
                'published_at' => $ad->published_at,
                'expires_at' => $ad->expires_at,
                'car' => $ad->load('car')->car,
            ],
        ]);
    }

    /**
     * نشر إعلان بيع (السماح بنشره عدة مرات)
     * الشروط:
     * 1. حالة الإعلان يجب أن تكون active (موافقة من الأدمن)
     * 2. حالة السيارة يجب أن تكون approved (ليست pending)
     * 3. يمكن نشره أكثر من مرة
     */
    public function publish(Request $request, $id)
    {
        $user = $request->user();
        $ad = Ad::where('id', $id)
                ->where('user_id', $user->id)
                ->with('car')
                ->first();

        if (!$ad) {
            return response()->json(['message' => 'الإعلان غير موجود.'], 404);
        }

        // التحقق من أن حالة الإعلان تكون active (موافقة من الأدمن)
        if ($ad->status !== 'active') {
            return response()->json([
                'message' => '❌ لا يمكن نشر هذا الإعلان!',
                'reason' => match($ad->status) {
                    'pending' => 'الإعلان بانتظار موافقة الإدارة',
                    'rejected' => 'الإعلان تم رفضه من قبل الإدارة',
                    'sold' => 'السيارة تم بيعها بالفعل',
                    default => 'الإعلان في حالة غير صحيحة'
                }
            ], 422);
        }

        // التحقق من أن حالة السيارة تكون approved (ليست pending)
        if ($ad->car->approval_status !== 'approved') {
            return response()->json([
                'message' => '❌ لا يمكن نشر إعلان لسيارة في حالة ' . $ad->car->approval_status,
                'reason' => 'السيارة يجب أن تكون موافق عليها من الإدارة أولاً'
            ], 422);
        }

        // تحديث تاريخ النشر والانتهاء
        $ad->published_at = now();
        $ad->expires_at = now()->addDays(30); // صلاحية الإعلان 30 يوم
        $ad->save();

        return response()->json([
            'message' => '✅ تم نشر الإعلان بنجاح!',
            'ad' => [
                'id' => $ad->id,
                'car_id' => $ad->car_id,
                'user_id' => $ad->user_id,
                'price' => $ad->price,
                'status' => $ad->status,
                'published_at' => $ad->published_at,
                'expires_at' => $ad->expires_at,
                'created_at' => $ad->created_at,
                'car' => [
                    'id' => $ad->car->id,
                    'make' => $ad->car->make,
                    'model' => $ad->car->model,
                    'year' => $ad->car->year,
                    'condition' => $ad->car->condition,
                ],
            ],
        ]);
    }

    /**
     * حذف إعلان
     */
    public function destroy(Request $request, $id)
    {
        $user = $request->user();
        $ad = Ad::where('id', $id)
                ->where('user_id', $user->id)
                ->first();

        if (!$ad) {
            return response()->json(['message' => 'الإعلان غير موجود.'], 404);
        }

        $ad->delete();

        return response()->json(['message' => 'تم حذف الإعلان بنجاح.'], 200);
    }
}
