<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use App\Services\NotificationService;

use Illuminate\Validation\Rule;

class CarController extends Controller
{
    /**
     * عرض جميع السيارات المنتظرة الموافقة
     */
    public function index()
    {
        $cars = Car::where('approval_status', 'pending')
                   ->with('user')
                   ->paginate(10);

        return response()->json([
            'message' => 'قائمة السيارات المنتظرة الموافقة',
            'cars' => $cars,
        ]);
    }

    /**
     * عرض جميع السيارات المرفوضة
     */
    public function rejected()
    {
        $cars = Car::where('approval_status', 'rejected')
                   ->with('user')
                   ->paginate(10);

        return response()->json([
            'message' => 'قائمة السيارات المرفوضة',
            'cars' => $cars,
        ]);
    }

    /**
     * عرض جميع السيارات المقبولة
     */
    public function approved()
    {
        $cars = Car::where('approval_status', 'approved')
                   ->with('user')
                   ->paginate(10);

        return response()->json([
            'message' => 'قائمة السيارات المقبولة',
            'cars' => $cars,
        ]);
    }

    /**
     * عرض تفاصيل سيارة محددة
     */
    public function show($id)
    {
        $car = Car::with('user', 'ad')->find($id);

        if (!$car) {
            return response()->json(['message' => 'السيارة غير موجودة.'], 404);
        }

        return response()->json([
            'message' => 'تفاصيل السيارة',
            'car' => $car,
        ]);
    }

    /**
     * موافقة الأدمن على سيارة
     */
    public function approve(Request $request, $id)
    {
        $car = Car::find($id);

        if (!$car) {
            return response()->json(['message' => 'السيارة غير موجودة.'], 404);
        }

        if ($car->approval_status === 'approved') {
            return response()->json(['message' => 'السيارة موافق عليها بالفعل.'], 400);
        }

        $car->update([
            'approval_status' => 'approved',
            'approval_reason' => $request->reason ?? null,
            'approved_at' => now(),
        ]);

        // إرسال إشعار للمستخدم
        NotificationService::send(
            $car->user_id,
            'تم قبول السيارة',
            'تمت الموافقة على السيارة ' . $car->make . ' ' . $car->model . ' بنجاح.',
            'car_approved',
            ['car_id' => $car->id]
        );

        return response()->json([
            'message' => 'تم الموافقة على السيارة بنجاح.',
            'car' => $car,
        ]);
    }

    /**
     * رفض الأدمن لسيارة
     */
    public function reject(Request $request, $id)
    {
        $request->validate([
            'reason' => 'required|string|max:500',
        ]);

        $car = Car::find($id);

        if (!$car) {
            return response()->json(['message' => 'السيارة غير موجودة.'], 404);
        }

        if ($car->approval_status === 'rejected') {
            return response()->json(['message' => 'السيارة مرفوضة بالفعل.'], 400);
        }

        $car->update([
            'approval_status' => 'rejected',
            'approval_reason' => $request->reason,
            'approved_at' => null,
        ]);

        // إرسال إشعار للمستخدم
        NotificationService::send(
            $car->user_id,
            'تم رفض السيارة',
            'تم رفض السيارة ' . $car->make . ' ' . $car->model . ' للسبب: ' . $request->reason,
            'car_rejected',
            ['car_id' => $car->id]
        );

        return response()->json([
            'message' => 'تم رفض السيارة بنجاح.',
            'car' => $car,
        ]);
    }




public function approveInspection(Request $request, $id)
{
    // التحقق من إرفاق ملف التقرير الفني وحجمه وامتداده
    $request->validate([
        'inspection_report' => 'required|file|mimes:pdf,jpg,jpeg,png|max:5120', // كحد أقصى 5 ميغا
    ]);

    $car = Car::findOrFail($id);

    if ($request->hasFile('inspection_report')) {
        // تخزين الملف في مجلد السيرفر (storage/app/public/reports)
        $filePath = $request->file('inspection_report')->store('reports', 'public');

        // تحديث حالة السيارة وتفعيل الشارة وتخزين الوقت
        $car->update([
            'is_inspected' => true,
            'inspection_report_path' => $filePath,
            'inspected_at' => now(),
        ]);

        // إرسال إشعار للمستخدم يعلمه بنجاح الفحص وتوثيق السيارة
        NotificationService::send(
            $car->user_id,
            'تهانينا! سيارتك أصبحت "مفحوصة ومضمونة" ✨',
            "تم اعتماد تقرير الفحص الفني لسيارتك ({$car->make} {$car->model}) وتفعيل الشارة لها في السوق بنجاح.",
            'car_inspection_approved',
            ['car_id' => $car->id, 'report_path' => asset('storage/' . $filePath)]
        );

        return response()->json([
            'success' => true,
            'message' => 'تم تفعيل شارة الفحص ورفع التقرير بنجاح، وإشعار صاحب السيارة إن شاء الله.'
        ]);
    }

    return response()->json(['success' => false, 'message' => 'حدث خطأ أثناء رفع الملف.'], 400);
}

}
