<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Auction;
use App\Models\Car; // تأكد من استيراد نموذج السيارة
use App\Models\User; // تأكد من استيراد نموذج المستخدم (البائع)
use Illuminate\Validation\Rule;
use App\Services\NotificationService;

class AuctionController extends Controller
{
    /**
     * Display a listing of the auctions.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        // Fetch auctions with their associated car and user (seller)
        $auctions = Auction::with(['car', 'user'])->paginate(10);
        return view('admin.auctions.index', compact('auctions'));
    }

    /**
     * Display the specified auction.
     *
     * @param  \App\Models\Auction  $auction
     * @return \Illuminate\View\View
     */
    public function show(Auction $auction)
    {
        // Load relationships for detailed view, including bids
        $auction->load('car.user', 'user', 'bids.user'); // Load car, seller, and bids with their users
        return view('admin.auctions.show', compact('auction'));
    }

    /**
     * Show the form for editing the specified auction.
     *
     * @param  \App\Models\Auction  $auction
     * @return \Illuminate\View\View
     */
    public function edit(Auction $auction)
    {
        $statuses = ['pending', 'active', 'cancelled'];

        return view('admin.auctions.edit', compact('auction', 'statuses'));
    }

    /**
     * Update the specified auction in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Auction  $auction
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, Auction $auction)
    {
        $request->validate([
            'status' => ['required', 'string', Rule::in(['pending', 'active', 'cancelled'])],
            'starting_price' => 'required|numeric|min:0',
            'current_price' => 'nullable|numeric|min:0|gte:starting_price',
            'start_time' => 'required|date',
            'end_time' => 'required|date|after:start_time',
        ]);

        $oldStatus = $auction->status;

        if ($request->status === 'cancelled') {
            $auction->update([
                'status' => 'cancelled',
                'starting_price' => $request->starting_price,
                'current_price' => $request->current_price,
                'start_time' => $request->start_time,
                'end_time' => $request->end_time,
                'winner_id' => null,
                'final_price_status' => null,
                'final_price_decided_at' => null,
                'closed_at' => null,
                'closed_reason' => null,
            ]);

            if ($oldStatus !== 'cancelled') {
                NotificationService::send(
                    $auction->user_id,
                    'تم إلغاء المزاد',
                    'قامت الإدارة بإلغاء المزاد الخاص بك لسبب إداري أو طارئ.',
                    'auction_cancelled_by_admin',
                    [
                        'auction_id' => $auction->id,
                    ]
                );
            }

            return redirect()
                ->route('admin.auctions.index')
                ->with('success', 'تم إلغاء المزاد بنجاح.');
        }

        if ($request->status === 'active') {
            $auction->update([
                'status' => 'active',
                'starting_price' => $request->starting_price,
                'current_price' => $request->current_price,
                'start_time' => $request->start_time,
                'end_time' => $request->end_time,
                'winner_id' => null,
                'final_price_status' => null,
                'final_price_decided_at' => null,
                'closed_at' => null,
                'closed_reason' => null,
            ]);

            if ($oldStatus !== 'active') {
                NotificationService::send(
                    $auction->user_id,
                    'تم قبول المزاد',
                    'تمت الموافقة على مزاد السيارة الخاص بك وأصبح فعالًا.',
                    'auction_approved',
                    [
                        'auction_id' => $auction->id,
                    ]
                );
            }

            return redirect()
                ->route('admin.auctions.index')
                ->with('success', 'تم تحديث المزاد بنجاح.');
        }

        $auction->update([
            'status' => $request->status,
            'starting_price' => $request->starting_price,
            'current_price' => $request->current_price,
            'start_time' => $request->start_time,
            'end_time' => $request->end_time,
        ]);

        return redirect()
            ->route('admin.auctions.index')
            ->with('success', 'تم تحديث المزاد بنجاح.');
    }

    // public function update(Request $request, Auction $auction)
    // {
    //     $request->validate([
    //         'status' => ['required', 'string', Rule::in(['pending', 'active', 'closed', 'cancelled'])],
    //         'starting_price' => 'required|numeric|min:0',
    //         'current_price' => 'nullable|numeric|min:0|gte:starting_price',
    //         'start_time' => 'required|date',
    //         'end_time' => 'required|date|after:start_time',
    //         'winner_id' => 'nullable|exists:users,id',
    //     ]);

    //     // حفظ حالة المزاد والفائز قبل التعديل
    //     $oldStatus = $auction->status;
    //     $oldWinnerId = $auction->winner_id;

    //     // تحديث المزاد
    //     $auction->update([
    //         'status' => $request->status,
    //         'starting_price' => $request->starting_price,
    //         'current_price' => $request->current_price,
    //         'start_time' => $request->start_time,
    //         'end_time' => $request->end_time,
    //         'winner_id' => $request->winner_id,
    //     ]);

    //     // إرسال إشعارات فقط إذا تغيّرت الحالة أو تغيّر الفائز
    //     if ($oldStatus !== $auction->status || $oldWinnerId != $auction->winner_id) {

    //         if ($auction->status === 'active' && $oldStatus !== 'active') {
    //             NotificationService::send(
    //                 $auction->user_id,
    //                 'تم قبول المزاد',
    //                 'تمت الموافقة على مزاد السيارة الخاص بك وأصبح فعالاً.',
    //                 'auction_approved',
    //                 [
    //                     'auction_id' => $auction->id,
    //                 ]
    //             );
    //         }

    //         if ($auction->status === 'cancelled' && $oldStatus !== 'cancelled') {
    //             NotificationService::send(
    //                 $auction->user_id,
    //                 'تم إلغاء المزاد',
    //                 'قامت الإدارة بإلغاء مزاد السيارة الخاص بك.',
    //                 'auction_cancelled',
    //                 [
    //                     'auction_id' => $auction->id,
    //                 ]
    //             );
    //         }

    //         if ($auction->status === 'closed' && $oldStatus !== 'closed') {
    //             NotificationService::send(
    //                 $auction->user_id,
    //                 'تم إغلاق المزاد',
    //                 'تم إغلاق المزاد الخاص بك.',
    //                 'auction_closed',
    //                 [
    //                     'auction_id' => $auction->id,
    //                     'winner_id' => $auction->winner_id,
    //                     'current_price' => $auction->current_price,
    //                 ]
    //             );
    //         }

    //         if (
    //             $auction->status === 'closed'
    //             && $auction->winner_id
    //             && $oldWinnerId != $auction->winner_id
    //         ) {
    //             NotificationService::send(
    //                 $auction->winner_id,
    //                 'مبروك، لقد فزت بالمزاد',
    //                 'تم تحديدك كفائز في أحد المزادات.',
    //                 'auction_won',
    //                 [
    //                     'auction_id' => $auction->id,
    //                     'current_price' => $auction->current_price,
    //                 ]
    //             );
    //         }
    //     }

    //     return redirect()
    //         ->route('admin.auctions.index')
    //         ->with('success', 'تم تحديث المزاد بنجاح.');
    // }
    /**
     * Remove the specified auction from storage.
     *
     * @param  \App\Models\Auction  $auction
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy(Auction $auction)
    {
        // Optionally, delete associated bids first if they don't cascade automatically
        // $auction->bids()->delete();
        $auction->delete();
        return redirect()->route('admin.auctions.index')->with('success', 'Auction deleted successfully.');
    }
}
