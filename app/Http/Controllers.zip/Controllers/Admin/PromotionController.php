<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Promotion;
use Illuminate\Http\Request;
use App\Services\NotificationService;
use App\Services\FollowerNotificationService;


class PromotionController extends Controller
{
    public function index()
    {
        $promotions = Promotion::with('user')
            ->latest()
            ->paginate(10);

        return view('admin.promotions.index', compact('promotions'));
    }

    public function show(Promotion $promotion)
    {
        $promotion->load('user');

        return view('admin.promotions.show', compact('promotion'));
    }

    public function edit(Promotion $promotion)
    {
        $promotion->load('user');

        return view('admin.promotions.edit', compact('promotion'));
    }

    // public function update(Request $request, Promotion $promotion)
    // {
    //     $validated = $request->validate([
    //         'status' => ['required', Rule::in(['pending', 'active', 'rejected', 'expired'])],
    //     ]);

    //     $promotion->update($validated);

    //     return redirect()
    //         ->route('admin.promotions.index')
    //         ->with('success', 'تم تحديث حالة العرض الترويجي بنجاح.');
    // }
    public function update(Request $request, Promotion $promotion)
    {
        $validated = $request->validate([
            'status' => ['required', \Illuminate\Validation\Rule::in(['pending', 'active', 'rejected', 'expired'])],
        ]);

        $oldStatus = $promotion->status;

        $promotion->update($validated);

        if ($oldStatus !== $promotion->status) {
            if ($promotion->status === 'active') {
                NotificationService::send(
                    $promotion->user_id,
                    'تم قبول العرض الترويجي',
                    'قامت الإدارة بتفعيل عرضك الترويجي: ' . $promotion->title,
                    'promotion_active',
                    [
                        'promotion_id' => $promotion->id,
                    ]
                );
            }

            if ($promotion->status === 'rejected') {
                NotificationService::send(
                    $promotion->user_id,
                    'تم رفض العرض الترويجي',
                    'قامت الإدارة برفض عرضك الترويجي: ' . $promotion->title,
                    'promotion_rejected',
                    [
                        'promotion_id' => $promotion->id,
                    ]
                );
            }

            if ($promotion->status === 'expired') {
                NotificationService::send(
                    $promotion->user_id,
                    'انتهى العرض الترويجي',
                    'تم تعليم عرضك الترويجي كمنتهي: ' . $promotion->title,
                    'promotion_expired',
                    [
                        'promotion_id' => $promotion->id,
                    ]
                );
            }
        }
        $promotion->load('user.accountType');

        if ($oldStatus !== 'active' && $promotion->status === 'active') {
            $owner = $promotion->user;

            if ($owner && $owner->accountType && $owner->accountType->name === 'company') {
                FollowerNotificationService::notifyCompanyFollowers(
                    $owner,
                    'عرض ترويجي جديد من ' . $owner->name,
                    'قامت الشركة التي تتابعها بنشر عرض ترويجي جديد: ' . $promotion->title,
                    'followed_company_new_promotion',
                    [
                        'promotion_id' => $promotion->id,
                        'target_type' => 'promotion',
                        'target_id' => $promotion->id,
                    ]
                );
            }
        }

        return redirect()
            ->route('admin.promotions.index')
            ->with('success', 'تم تحديث حالة العرض الترويجي بنجاح.');
    }

    public function destroy(Promotion $promotion)
    {
        $promotion->delete();

        return redirect()
            ->route('admin.promotions.index')
            ->with('success', 'تم حذف العرض الترويجي بنجاح.');
    }

    /**
     * عرض العروض الترويجية قيد المراجعة (pending)
     */
    public function pending()
    {
        $promotions = Promotion::where('status', 'pending')
            ->with('user')
            ->latest()
            ->get();

        return response()->json([
            'message' => 'تم جلب العروض الترويجية قيد المراجعة بنجاح.',
            'count' => $promotions->count(),
            'promotions' => $promotions->map(function ($promotion) {
                return [
                    'id' => $promotion->id,
                    'user_id' => $promotion->user_id,
                    'title' => $promotion->title,
                    'description' => $promotion->description,
                    'status' => $promotion->status,
                    'budget' => $promotion->budget,
                    'start_date' => $promotion->start_date,
                    'end_date' => $promotion->end_date,
                    'created_at' => $promotion->created_at,
                    'user' => [
                        'id' => $promotion->user->id,
                        'name' => $promotion->user->name,
                        'email' => $promotion->user->email,
                    ],
                ];
            }),
        ]);
    }

    /**
     * عرض العروض الترويجية الموافق عليها (approved)
     */
    public function approved()
    {
        $promotions = Promotion::where('status', 'active')
            ->with('user')
            ->latest()
            ->get();

        return response()->json([
            'message' => 'تم جلب العروض الترويجية الموافق عليها بنجاح.',
            'count' => $promotions->count(),
            'promotions' => $promotions->map(function ($promotion) {
                return [
                    'id' => $promotion->id,
                    'user_id' => $promotion->user_id,
                    'title' => $promotion->title,
                    'description' => $promotion->description,
                    'status' => $promotion->status,
                    'budget' => $promotion->budget,
                    'start_date' => $promotion->start_date,
                    'end_date' => $promotion->end_date,
                    'created_at' => $promotion->created_at,
                    'user' => [
                        'id' => $promotion->user->id,
                        'name' => $promotion->user->name,
                        'email' => $promotion->user->email,
                    ],
                ];
            }),
        ]);
    }

    /**
     * عرض العروض الترويجية المرفوضة (rejected)
     */
    public function rejected()
    {
        $promotions = Promotion::where('status', 'rejected')
            ->with('user')
            ->latest()
            ->get();

        return response()->json([
            'message' => 'تم جلب العروض الترويجية المرفوضة بنجاح.',
            'count' => $promotions->count(),
            'promotions' => $promotions->map(function ($promotion) {
                return [
                    'id' => $promotion->id,
                    'user_id' => $promotion->user_id,
                    'title' => $promotion->title,
                    'description' => $promotion->description,
                    'status' => $promotion->status,
                    'budget' => $promotion->budget,
                    'start_date' => $promotion->start_date,
                    'end_date' => $promotion->end_date,
                    'created_at' => $promotion->created_at,
                    'user' => [
                        'id' => $promotion->user->id,
                        'name' => $promotion->user->name,
                        'email' => $promotion->user->email,
                    ],
                ];
            }),
        ]);
    }

    /**
     * موافقة الأدمن على العرض الترويجي
     */
    public function approve($id)
    {
        $promotion = Promotion::find($id);

        if (!$promotion) {
            return response()->json(['message' => 'العرض الترويجي غير موجود.'], 404);
        }

        $promotion->status = 'active';
        $promotion->save();

        // إرسال إشعار للمستخدم
        NotificationService::send(
            $promotion->user_id,
            '✅ تم قبول العرض الترويجي',
            'قامت الإدارة بتفعيل عرضك الترويجي: ' . $promotion->title,
            'promotion_active',
            [
                'promotion_id' => $promotion->id,
            ]
        );

        // إشعار المتابعين إذا كان المالك شركة
        $owner = $promotion->user;
        if ($owner && $owner->accountType && $owner->accountType->name === 'company') {
            FollowerNotificationService::notifyCompanyFollowers(
                $owner,
                'عرض ترويجي جديد من ' . $owner->name,
                'قامت الشركة التي تتابعها بنشر عرض ترويجي جديد: ' . $promotion->title,
                'followed_company_new_promotion',
                [
                    'promotion_id' => $promotion->id,
                    'target_type' => 'promotion',
                    'target_id' => $promotion->id,
                ]
            );
        }

        return response()->json([
            'message' => '✅ تم قبول العرض الترويجي بنجاح!',
            'promotion' => [
                'id' => $promotion->id,
                'title' => $promotion->title,
                'status' => $promotion->status,
                'created_at' => $promotion->created_at,
            ],
        ]);
    }

    /**
     * رفض الأدمن للعرض الترويجي
     */
    public function reject(Request $request, $id)
    {
        $promotion = Promotion::find($id);

        if (!$promotion) {
            return response()->json(['message' => 'العرض الترويجي غير موجود.'], 404);
        }

        $promotion->status = 'rejected';
        $promotion->save();

        // إرسال إشعار للمستخدم برفضه
        NotificationService::send(
            $promotion->user_id,
            '❌ تم رفض العرض الترويجي',
            'قامت الإدارة برفض عرضك الترويجي: ' . $promotion->title . '. السبب: ' . ($request->input('reason') ?? 'لم يتم تحديد السبب'),
            'promotion_rejected',
            [
                'promotion_id' => $promotion->id,
            ]
        );

        return response()->json([
            'message' => '❌ تم رفض العرض الترويجي بنجاح!',
            'reason' => $request->input('reason'),
            'promotion' => [
                'id' => $promotion->id,
                'title' => $promotion->title,
                'status' => $promotion->status,
                'created_at' => $promotion->created_at,
            ],
        ]);
    }
