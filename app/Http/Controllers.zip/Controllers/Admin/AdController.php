<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Ad;
use App\Models\Car; // تأكد من استيراد نموذج السيارة
use App\Models\User; // تأكد من استيراد نموذج المستخدم
use Illuminate\Validation\Rule;
use App\Services\NotificationService;
use App\Services\FollowerNotificationService;
use App\Services\VehicleFraudDetectionService;


class AdController extends Controller
{
    /**
     * عرض قائمة بجميع إعلانات البيع.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        // جلب الإعلانات مع السيارة المرتبطة بها والمستخدم (البائع)
        // استخدام with() لتجنب مشكلة N+1 query
        $ads = Ad::with(['car', 'user'])->paginate(10);
        return view('admin.ads.index', compact('ads'));
    }

    /**
     * عرض تفاصيل إعلان بيع محدد.
     *
     * @param  \App\Models\Ad  $ad
     * @return \Illuminate\View\View
     */
    public function show(Ad $ad)
    {
        // تحميل العلاقات اللازمة للعرض التفصيلي
        $ad->load('car.user', 'user'); // تحميل السيارة ومالكها، وبائع الإعلان
        return view('admin.ads.show', compact('ad'));
    }

    /**
     * عرض نموذج تعديل إعلان بيع محدد.
     *
     * @param  \App\Models\Ad  $ad
     * @return \Illuminate\View\View
     */
    public function edit(Ad $ad)
    {
        // تعريف الحالات المحتملة للإعلان
        $statuses = ['pending', 'active', 'sold', 'rejected'];
        return view('admin.ads.edit', compact('ad', 'statuses'));
    }

    /**
     * تحديث إعلان بيع محدد في قاعدة البيانات.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Ad  $ad
     * @return \Illuminate\Http\RedirectResponse
     */

    public function update(Request $request, Ad $ad)
    {
        $request->validate([
            'status' => ['required', 'string', Rule::in(['pending', 'active', 'sold', 'rejected'])],
            'price' => 'required|numeric|min:0',
            'published_at' => 'nullable|date',
            'expires_at' => 'nullable|date|after_or_equal:published_at',
        ]);

        // حفظ حالة الإعلان قبل التعديل
        $oldStatus = $ad->status;

        // تحديث الإعلان
        $ad->update([
            'status' => $request->status,
            'price' => $request->price,
            'published_at' => $request->published_at,
            'expires_at' => $request->expires_at,
        ]);

        // إرسال إشعار فقط إذا تغيرت الحالة
        if ($oldStatus !== $ad->status) {

            if ($ad->status === 'active') {
                NotificationService::send(
                    $ad->user_id,
                    'تم قبول إعلان البيع',
                    'تمت الموافقة على إعلان البيع الخاص بك وأصبح فعالاً.',
                    'ad_approved',
                    [
                        'ad_id' => $ad->id,
                    ]
                );
            }

            if ($ad->status === 'rejected') {
                NotificationService::send(
                    $ad->user_id,
                    'تم رفض إعلان البيع',
                    'قامت الإدارة برفض إعلان البيع الخاص بك.',
                    'ad_rejected',
                    [
                        'ad_id' => $ad->id,
                    ]
                );
            }

            if ($ad->status === 'sold') {
                NotificationService::send(
                    $ad->user_id,
                    'تم تعليم إعلان البيع كمباع',
                    'تم تغيير حالة إعلان البيع الخاص بك إلى مباع.',
                    'ad_sold',
                    [
                        'ad_id' => $ad->id,
                    ]
                );
            }
        }
        $ad->load('user.accountType');

        if ($oldStatus !== 'active' && $ad->status === 'active') {
            $owner = $ad->user;

            if ($owner && $owner->accountType && $owner->accountType->name === 'company') {
                $adTitle = $ad->title ?? ('إعلان بيع رقم ' . $ad->id);

                FollowerNotificationService::notifyCompanyFollowers(
                    $owner,
                    'إعلان جديد من ' . $owner->name,
                    'قامت الشركة التي تتابعها بنشر إعلان بيع جديد: ' . $adTitle,
                    'followed_company_new_sale_ad',
                    [
                        'ad_id' => $ad->id,
                        'target_type' => 'sale_ad',
                        'target_id' => $ad->id,
                    ]
                );
            }
        }

        return redirect()
            ->route('admin.ads.index')
            ->with('success', 'تم تحديث الإعلان بنجاح.');
    }
    /**
     * حذف إعلان بيع محدد من قاعدة البيانات.
     *
     * @param  \App\Models\Ad  $ad
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy(Ad $ad)
    {
        $ad->delete();
        return redirect()->route('admin.ads.index')->with('success', 'تم حذف الإعلان بنجاح.');
    }

    /**
     * عرض الإعلانات المنتظرة الموافقة (API)
     */
    public function pendingAds()
    {
        $ads = Ad::where('approval_status', 'pending')
                 ->with(['car', 'user'])
                 ->paginate(10);

        return response()->json([
            'message' => 'قائمة الإعلانات المنتظرة الموافقة',
            'ads' => $ads,
        ]);
    }

    /**
     * عرض الإعلانات المرفوضة (API)
     */
    public function rejectedAds()
    {
        $ads = Ad::where('approval_status', 'rejected')
                 ->with(['car', 'user'])
                 ->paginate(10);

        return response()->json([
            'message' => 'قائمة الإعلانات المرفوضة',
            'ads' => $ads,
        ]);
    }

    /**
     * عرض الإعلانات المقبولة (API)
     */
    public function approvedAds()
    {
        $ads = Ad::where('approval_status', 'approved')
                 ->with(['car', 'user'])
                 ->paginate(10);

        return response()->json([
            'message' => 'قائمة الإعلانات المقبولة',
            'ads' => $ads,
        ]);
    }

    /**
     * عرض تفاصيل إعلان محدد (API)
     */
    public function showAd($id)
    {
        $ad = Ad::with(['car.user', 'user'])->find($id);

        if (!$ad) {
            return response()->json(['message' => 'الإعلان غير موجود.'], 404);
        }

        // تحليل الاحتيال — يظهر للأدمن قبل اتخاذ قرار الموافقة أو الرفض
        $fraudReport = (new VehicleFraudDetectionService())->analyze($ad->car);

        return response()->json([
            'message' => 'تفاصيل الإعلان',
            'ad' => $ad,
            'fraud_report' => $fraudReport,
        ]);
    }

    /**
     * موافقة الأدمن على إعلان
     */
    public function approveAd(Request $request, $id)
    {
        $ad = Ad::find($id);

        if (!$ad) {
            return response()->json(['message' => 'الإعلان غير موجود.'], 404);
        }

        if ($ad->approval_status === 'approved') {
            return response()->json(['message' => 'الإعلان موافق عليه بالفعل.'], 400);
        }

        // تحليل الاحتيال قبل الموافقة
        $fraudReport = (new VehicleFraudDetectionService())->analyze($ad->car);

        // رفض تلقائي إذا كانت الإشارة قوية جداً
        if ($fraudReport['is_strong_fraud_signal']) {
            $ad->update([
                'approval_status' => 'rejected',
                'approval_reason' => 'تم رصد نشاط مشبوه: رقم الهيكل ظهر ' . $fraudReport['occurrences'] . ' مرات مع تضارب في الأسعار أو الأوصاف.',
                'status' => 'rejected',
            ]);

            NotificationService::send(
                $ad->user_id,
                'تم رفض الإعلان تلقائياً',
                'تم رفض إعلانك بسبب رصد نشاط مشبوه على رقم هيكل السيارة.',
                'ad_rejected',
                ['ad_id' => $ad->id, 'fraud_report' => $fraudReport]
            );

            return response()->json([
                'message' => '🚨 تم رفض الإعلان تلقائياً بسبب إشارة احتيال قوية.',
                'fraud_report' => $fraudReport,
                'ad' => $ad->load('car', 'user'),
            ], 422);
        }

        $ad->update([
            'approval_status' => 'approved',
            'approval_reason' => $request->reason ?? null,
            'approved_at' => now(),
            'status' => 'active', // تفعيل الإعلان تلقائياً
            'published_at' => now(),
        ]);

        // إرسال إشعار للمستخدم
        NotificationService::send(
            $ad->user_id,
            'تم قبول الإعلان',
            'تمت الموافقة على إعلان البيع الخاص بك وأصبح فعالاً.',
            'ad_approved',
            ['ad_id' => $ad->id]
        );

        // إشعار المتابعين إذا كان البائع شركة
        if ($ad->user && $ad->user->accountType && $ad->user->accountType->name === 'company') {
            FollowerNotificationService::notifyCompanyFollowers(
                $ad->user,
                'إعلان جديد من ' . $ad->user->name,
                'قامت الشركة التي تتابعها بنشر إعلان بيع جديد',
                'followed_company_new_sale_ad',
                ['ad_id' => $ad->id, 'target_type' => 'sale_ad', 'target_id' => $ad->id]
            );
        }

        return response()->json([
            'message' => 'تم الموافقة على الإعلان بنجاح.',
            'fraud_report' => $fraudReport,
            'ad' => $ad->load('car', 'user'),
        ]);
    }

    /**
     * رفض الأدمن لإعلان
     */
    public function rejectAd(Request $request, $id)
    {
        $request->validate([
            'reason' => 'required|string|max:500',
        ]);

        $ad = Ad::find($id);

        if (!$ad) {
            return response()->json(['message' => 'الإعلان غير موجود.'], 404);
        }

        if ($ad->approval_status === 'rejected') {
            return response()->json(['message' => 'الإعلان مرفوض بالفعل.'], 400);
        }

        $ad->update([
            'approval_status' => 'rejected',
            'approval_reason' => $request->reason,
            'approved_at' => null,
            'status' => 'rejected',
        ]);

        // إرسال إشعار للمستخدم
        NotificationService::send(
            $ad->user_id,
            'تم رفض الإعلان',
            'تم رفض إعلان البيع الخاص بك للسبب: ' . $request->reason,
            'ad_rejected',
            ['ad_id' => $ad->id]
        );

        return response()->json([
            'message' => 'تم رفض الإعلان بنجاح.',
            'ad' => $ad->load('car', 'user'),
        ]);
    }

    // يمكنك إضافة طرق create/store هنا إذا كان المدراء يمكنهم إنشاء الإعلانات مباشرة.
    // حالياً، نفترض أن الإعلانات يتم إنشاؤها بواسطة المستخدمين وأن المدراء يقومون بإدارتها فقط.
}
