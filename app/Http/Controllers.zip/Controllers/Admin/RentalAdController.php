<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\RentalAd;
use App\Models\Car; // Make sure to import the Car model
use App\Models\User; // Make sure to import the User model
use Illuminate\Validation\Rule;
use App\Services\NotificationService;
use App\Services\FollowerNotificationService;
use App\Services\VehicleFraudDetectionService;

class RentalAdController extends Controller
{
    /**
     * Display a listing of the rental ads.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        // Fetch rental ads with their associated car and user (renter)
        // Use with() to avoid N+1 query problem
        $rentalAds = RentalAd::with(['car', 'user'])->paginate(10);
        return view('admin.rental-ads.index', compact('rentalAds'));
    }

    /**
     * Display the specified rental ad.
     *
     * @param  \App\Models\RentalAd  $rentalAd
     * @return \Illuminate\View\View
     */
    public function show(RentalAd $rentalAd)
    {
        // Load relationships for detailed view
        $rentalAd->load('car.user', 'user'); // Load car and its owner, and the rental ad's renter
        return view('admin.rental-ads.show', compact('rentalAd'));
    }

    /**
     * Show the form for editing the specified rental ad.
     *
     * @param  \App\Models\RentalAd  $rentalAd
     * @return \Illuminate\View\View
     */
    public function edit(RentalAd $rentalAd)
    {
        // Define possible statuses for a rental ad
        $statuses = ['pending', 'active', 'rented', 'rejected'];
        return view('admin.rental-ads.edit', compact('rentalAd', 'statuses'));
    }

    /**
     * Update the specified rental ad in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\RentalAd  $rentalAd
     * @return \Illuminate\Http\RedirectResponse
     */

    public function update(Request $request, RentalAd $rentalAd)
    {
        $request->validate([
            'status' => ['required', 'string', Rule::in(['pending', 'active', 'rented', 'rejected'])],
            'daily_price' => 'nullable|numeric|min:0',
            'monthly_price' => 'nullable|numeric|min:0',
            'rental_conditions' => 'nullable|string',
            'location' => 'required|string|max:255',
        ]);

        // حفظ حالة إعلان التأجير قبل التعديل
        $oldStatus = $rentalAd->status;

        // فحص احتيال "التأجير المزدوج" فقط عند محاولة التفعيل (active)
        // قبل حفظ التحديث، لنعرف هل توجد إعلانات نشطة أخرى على نفس
        // رقم الهيكل من مستخدمين مختلفين (تأجير مزدوج محتمل)
        $rentalOverlapWarning = null;
        if ($oldStatus !== 'active' && $request->status === 'active') {
            $rentalAd->loadMissing('car');
            $overlapReport = (new VehicleFraudDetectionService())->analyzeRentalOverlap($rentalAd->car);

            if ($overlapReport['has_double_rental_conflict']) {
                $rentalOverlapWarning = '⚠️ تنبيه: تم رصد إعلان تأجير نشط آخر على سيارة تحمل نفس رقم الهيكل ('
                    . $rentalAd->car->vehicle_identifier
                    . ') من مستخدم مختلف. يرجى التحقق قبل المتابعة - قد يكون تأجيراً مزدوجاً.';
            }
        }

        // تحديث إعلان التأجير
        $rentalAd->update([
            'status' => $request->status,
            'daily_price' => $request->daily_price,
            'monthly_price' => $request->monthly_price,
            'rental_conditions' => $request->rental_conditions,
            'location' => $request->location,
        ]);

        // إرسال إشعار فقط إذا تغيّرت الحالة
        if ($oldStatus !== $rentalAd->status) {

            if ($rentalAd->status === 'active') {
                NotificationService::send(
                    $rentalAd->user_id,
                    'تم قبول إعلان التأجير',
                    'تمت الموافقة على إعلان التأجير الخاص بك وأصبح فعالاً.',
                    'rental_ad_approved',
                    [
                        'rental_ad_id' => $rentalAd->id,
                    ]
                );
            }

            if ($rentalAd->status === 'rejected') {
                NotificationService::send(
                    $rentalAd->user_id,
                    'تم رفض إعلان التأجير',
                    'قامت الإدارة برفض إعلان التأجير الخاص بك.',
                    'rental_ad_rejected',
                    [
                        'rental_ad_id' => $rentalAd->id,
                    ]
                );
            }

            if ($rentalAd->status === 'rented') {
                NotificationService::send(
                    $rentalAd->user_id,
                    'تم تعليم إعلان التأجير كمؤجر',
                    'تم تغيير حالة إعلان التأجير الخاص بك إلى مؤجر.',
                    'rental_ad_rented',
                    [
                        'rental_ad_id' => $rentalAd->id,
                    ]
                );
            }
        }
        $rentalAd->load('user.accountType');

        if ($oldStatus !== 'active' && $rentalAd->status === 'active') {
            $owner = $rentalAd->user;

            if ($owner && $owner->accountType && $owner->accountType->name === 'company') {
                $adTitle = $rentalAd->title ?? ('إعلان تأجير رقم ' . $rentalAd->id);

                FollowerNotificationService::notifyCompanyFollowers(
                    $owner,
                    'إعلان تأجير جديد من ' . $owner->name,
                    'قامت الشركة التي تتابعها بنشر إعلان تأجير جديد: ' . $adTitle,
                    'followed_company_new_rental_ad',
                    [
                        'rental_ad_id' => $rentalAd->id,
                        'target_type' => 'rental_ad',
                        'target_id' => $rentalAd->id,
                    ]
                );
            }
        }

        $redirect = redirect()->route('admin.rental-ads.index')
            ->with('success', 'تم تحديث إعلان التأجير بنجاح.');

        if ($rentalOverlapWarning) {
            $redirect->with('warning', $rentalOverlapWarning);
        }

        return $redirect;
    }
    /**
     * Remove the specified rental ad from storage.
     *
     * @param  \App\Models\RentalAd  $rentalAd
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy(RentalAd $rentalAd)
    {
        $rentalAd->delete();
        return redirect()->route('admin.rental-ads.index')->with('success', 'Rental Ad deleted successfully.');
    }
}
